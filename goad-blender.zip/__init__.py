bl_info = {
    "name": "goad",
    "blender": (3, 0, 0),
    "category": "Object",
    "author": "Your Name",
    "version": (1, 0, 0),
    "location": "View3D > Sidebar > Light Scattering",
    "description": "Compute light scattering for selected objects",
}

import sys
import os
from pathlib import Path

# Add lib directory to Python path
lib_path = Path(__file__).parent / "lib"
if str(lib_path) not in sys.path:
    sys.path.append(str(lib_path))

# Import the rest of the addon
from .blender_goad import register, unregister

if __name__ == "__main__":
    register()