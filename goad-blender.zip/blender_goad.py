bl_info = {
    "name": "Light Scattering",
    "blender": (3, 0, 0),
    "category": "Object",
    "author": "Your Name",
    "version": (1, 0, 0),
    "location": "View3D > Sidebar > Light Scattering",
    "description": "Compute light scattering for selected objects",
}

import sys
import os
from pathlib import Path

# Add lib directory to Python path
lib_path = Path(__file__).parent / "lib"
if str(lib_path) not in sys.path:
    sys.path.append(str(lib_path))

# Import the rest of the addon
from .blender_goad import register, unregister

import bpy
import goad_py  # Your Rust module

class SCATTERING_PT_Panel(bpy.types.Panel):
    """Light Scattering UI Panel"""
    bl_label = "goad"
    bl_idname = "SCATTERING_PT_Panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Light Scattering"

    def draw(self, context):
        layout = self.layout
        obj = context.object
        
        # Object selection
        if obj:
            layout.label(text=f"Selected: {obj.name}")
        else:
            layout.label(text="No object selected")

        # Light Scattering Controls
        layout.prop(context.scene, "scattering_intensity")
        layout.prop(context.scene, "scattering_angle")

        # Compute Scattering Button
        layout.operator("object.compute_scattering")

class OBJECT_OT_ComputeScattering(bpy.types.Operator):
    """Compute light scattering"""
    bl_idname = "object.compute_scattering"
    bl_label = "Compute Scattering"

    def execute(self, context):
        obj = context.object
        if obj is None:
            self.report({'WARNING'}, "No object selected")
            return {'CANCELLED'}

        # Extract mesh and light properties
        mesh_data = extract_mesh(obj)
        light_params = {
            "intensity": context.scene.scattering_intensity,
            "angle": context.scene.scattering_angle
        }

        # Call Rust module
        results = light_scattering.compute_scattering(mesh_data, light_params)

        # Apply results (to be implemented)
        apply_scattering_overlay(obj, results)

        return {'FINISHED'}

# Extract mesh vertices and faces
def extract_mesh(obj):
    vertices = [v.co for v in obj.data.vertices]
    faces = [f.vertices for f in obj.data.polygons]
    return {"vertices": vertices, "faces": faces}

# Register properties & classes
def register():
    bpy.utils.register_class(SCATTERING_PT_Panel)
    bpy.utils.register_class(OBJECT_OT_ComputeScattering)
    bpy.types.Scene.scattering_intensity = bpy.props.FloatProperty(name="Intensity", default=1.0, min=0.1, max=10.0)
    bpy.types.Scene.scattering_angle = bpy.props.FloatProperty(name="Angle", default=45.0, min=0.0, max=180.0)

def unregister():
    bpy.utils.unregister_class(SCATTERING_PT_Panel)
    bpy.utils.unregister_class(OBJECT_OT_ComputeScattering)
    del bpy.types.Scene.scattering_intensity
    del bpy.types.Scene.scattering_angle

if __name__ == "__main__":
    register()
